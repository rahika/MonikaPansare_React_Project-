type isLoading = "LOADING" | "LOADED" | "ERROR";

export type { isLoading };
